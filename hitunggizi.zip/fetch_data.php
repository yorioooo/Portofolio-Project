<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

require 'db_connect.php';

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil data
$sql = "SELECT id, gender, age, weight, height, bmi, classification FROM nutrition_data"; // Ganti dengan nama tabel Anda
$result = $conn->query($sql);

$data = [];

if ($result->num_rows > 0) {
    // Ambil setiap baris data
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Mengembalikan data dalam format JSON
echo json_encode($data);

$conn->close();
