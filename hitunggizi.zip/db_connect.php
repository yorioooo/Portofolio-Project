<?php
$servername = "localhost";
$username = "hitunggi_dani";
$password = "zB!yviZPiOS4";
$dbname = "hitunggi_dani";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
